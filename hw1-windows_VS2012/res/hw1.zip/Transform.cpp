// Transform.cpp: implementation of the Transform class.


#include "Transform.h"
#include <stdio.h>
//Please implement the following functions:

// Helper rotation function.  
mat3 Transform::rotate(const float degrees, const vec3& axis) {
  // YOUR CODE FOR HW1 HERE
	vec3 _up = glm::normalize(axis);
	float x = _up.x;
	float y = _up.y;
	float z = _up.z;
	
	glm::mat3 m1(1, 0, 0, 0, 1, 0, 0, 0, 1);
	m1 = glm::transpose(m1);
	glm::mat3 m2(x*x, x*y, x*z, x*y, y*y, y*z, x*z, y*z, z*z);
	m2 = glm::transpose(m2);
	glm::mat3 m3(0, -z, y, z, 0, -x, -y, x, 0);
	m3 = glm::transpose(m3);
	glm::mat3 m4 = cos(degrees*pi / 180.0)*m1 + (1 - cos(degrees*pi / 180.0))*m2 + sin(degrees*pi / 180.0)*m3;
  // You will change this return call
	 return m4;
}

// Transforms the camera left around the "crystal ball" interface
void Transform::left(float degrees, vec3& eye, vec3& up) {
	// YOUR CODE FOR HW1 HERE

	eye = rotate(degrees, up)*eye;
}

// Transforms the camera up around the "crystal ball" interface
void Transform::up(float degrees, vec3& eye, vec3& up) {
  // YOUR CODE FOR HW1 HERE
	vec3 _w = glm::normalize(eye );
	vec3 _u = glm::normalize(glm::cross(up, _w));
	vec3 _v = glm::cross(_w, _u);
	eye= rotate(-degrees, _u) *eye;
	up = glm::cross(eye, _u);
}

// Your implementation of the glm::lookAt matrix
mat4 Transform::lookAt(vec3 eye, vec3 up) {
  // YOUR CODE FOR HW1 HERE
	vec3 _w = glm::normalize(eye - vec3(0, 0, 0));
	vec3 _u = glm::normalize(glm::cross(up, _w));
	vec3 _v = glm::normalize(glm::cross(_w, _u));
	mat4 l(_u.x,_u.y,_u.z,0,_v.x,_v.y,_v.z,0,_w.x,_w.y,_w.z,0,0,0,0,1);
	l = glm::transpose(l);
	mat4 r(1, 0, 0, 0 - eye.x, 0, 1, 0, 0 - eye.y, 0, 0, 1, 0 - eye.z, 0, 0, 0, 1);
	r = glm::transpose(r);
	mat4 fin = l*r;
  // You will change this return call
  return fin;
}

Transform::Transform()
{

}

Transform::~Transform()
{

}
